import UIKit

//class sorting {
//    func bubbleSorting(_ array: [Int]) -> [Int] {  // o(n2)
//        var arr = array
//        for i in 0..<arr.count - 1 {
//            for j in 0..<arr.count - 1 - i {
//                if arr[j] > arr[j+1] {
//                    let temp = arr[j]
//                    arr[j] = arr[j+1]
//                    arr[j+1] = temp
//                }
//            }
//        }
//        return arr
//    }
//}
//let arr = [3,2,1]
//let w = sorting()
//w.bubbleSorting(arr)
//----------------selection sort o(n2) in best and worst
//var nums = [3,2,1,4]
//var miniIndex = 0
//for i in 0..<nums.count{
//    miniIndex = i // i was miniIndex just assume that it was
//    for j in (i+1)..<nums.count{
//        if nums[j] < nums[miniIndex]{ // miniIndex was smaller than we find one than assign that to new one
//            miniIndex = j   //new variable for storing new one smaller value means new miniIndex
//        }
//        nums.swapAt(i, miniIndex)
////        let temp = nums[i]
////        nums[i] = nums[miniIndex]
////        nums[miniIndex] = temp
//    }
//}
//print(nums)
//-----------------------insertion Sort o(n) in best case and o(n2)
//var num = [3,2,1]
//for i in 1..<num.count{
//    let key = i
//    var j = i - 1
//    while (j >= 0 && num[j] > key) {
//        num[j + 1] = num[j]
//        j = j - 1
//    }
//    num[j+1] = key
//}
//print(num)
//--------------------quene


